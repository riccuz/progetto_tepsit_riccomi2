//dichiarazioni librerie
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <math.h>
#include <sys/stat.h>   // mkfifo
#include <fcntl.h>
#include <string.h> 
//fine dichiarazioni librerie

#define MSGSIZE 256

int main() {
    
    
    
    //variabili
    char scelta;// decisione su cui canale trasmettere
    char dom[256]; // messaggio
    pid_t utenteA; //processo che con la fork aspetterà i messaggi quando il padre scriverà
    pid_t utenteB; //stessa cosa ma solo con il canale b
// FINE VARIABILI




    // Inizio creazione pipe
    char canaleA[] = "/tmp/canaleA"; //canaleA----->server
    char canaleB[] = "/tmp/canaleB";// canaleB----->server
    char serverB[] = "/tmp/serverB";// server------> canaleB
    char serverA[] = "/tmp/serverA";// server------>canaleA

    // PIPE 1 - da canaleA a server
    mkfifo(canaleA, 0666);
    int let = open(canaleA, O_RDONLY | O_NONBLOCK); // lettore aperto momentaneamente,altrimenti dava errore nella creazione della pipe
    int fd = open(canaleA, O_WRONLY | O_NONBLOCK);
    if (fd == -1) {
        perror("Errore apertura PRIMA pipe");
        return 1;
    }
    close(let);// chiudo il lettore aperto in precedenza

    // PIPE 2 - da canaleB a server
    mkfifo(canaleB, 0666);
    int let2 = open(canaleB, O_RDONLY | O_NONBLOCK); // lettore dummy
    int fd2 = open(canaleB, O_WRONLY | O_NONBLOCK);
    if (fd2 == -1) {
        perror("Errore apertura SECONDA pipe");
        return 1;
    }
    close(let2);

    // PIPE 3 - da server a canaleB
    mkfifo(serverB, 0666);
    int fd3 = open(serverB, O_RDONLY | O_NONBLOCK );
    if (fd3 == -1) {
        printf("Errore apertura TERZA pipe");
        return 1;
    }

    // PIPE 4 - da server a canaleA
    mkfifo(serverA, 0666);
    int fd4 = open(serverA, O_RDONLY | O_NONBLOCK);
    if (fd4 == -1) {
        printf("Errore apertura QUARTA pipe");
        return 1;
    }
// FINE CREAZIONE PIPE




//INIZIO MAIN




    // Se siamo qui, tutte le pipe sono state aperte correttamente
    printf("Ciao e benvenuto in Discord! Da dove vuoi trasmettere il messaggio, da canaleA o da canaleB? ");
    scanf(" %c", &scelta);

    utenteA = fork();
    if(utenteA==0){
        while(1){ 
            read(fd4,dom,sizeof(dom)); //faccio aspettare un messaggio imporvviso mentre sto scrivendo,lo faccio aspettare al figlio, almeno il padre può scrivere
            exit(0);
        }
    }
if(utenteA>0){// il padre scrive
    if (scelta == 'a') {
         
            printf("Bene! Hai scelto canale A, perfavore immetti il messaggio: ");
            scanf(" %255s", dom);  // leggi una stringa, massimo 255 caratteri
            int n = write(fd, dom, strlen(dom) + 1);  //hho usato strlen a causa di un errore con sizeof(dom)
            
            if (n == -1) {
                perror("Errore nella scrittura");
            }else{
                printf("messaggio inviato correttamente al server che lo invierà al canale b");
            }
    }  
    }else{
        utenteB=fork();
        if(utenteB==0){// faccio aspettare un messaggio imporvviso, nel mentre,il padre scrive
            while(1){
                read(fd3,dom,sizeof(dom));
            }
            exit(0);
        }
        printf("Bene! Hai scelto canale B, perfavore immetti il messaggio: ");
            scanf(" %255s", dom);  // leggi una stringa, massimo 255
             int n = write(fd2, dom, strlen(dom) + 1); 
             if (n == -1) {
                perror("Errore nella scrittura");
            }else{
                printf("messaggio inviato correttamente al server che lo invierà al canale a");
            }
    }

    return 0;
}
//FINE MAIN