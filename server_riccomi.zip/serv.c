// Online C compiler to run C program online
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <math.h>
#include <sys/stat.h>   // mkfifo
#include <fcntl.h>
#include <string.h>
int main() {
     char dom[256]; // messaggio
    // Inizio creazione pipe
    char canaleA[] = "/tmp/canaleA"; //canaleA----->server
    char canaleB[] = "/tmp/canaleB";// canaleB----->server
    char serverB[] = "/tmp/serverB";// server------> canaleB
    char serverA[] = "/tmp/serverA";// server------>canaleA

 // PIPE 1 - da canaleA a server
    mkfifo(canaleA, 0666);

    int fd = open(canaleA, O_RDONLY | O_NONBLOCK); // apro solo in lettura
    if (fd == -1) {
        perror("Errore apertura PRIMA pipe");
        return 1;
    }
    

    // PIPE 2 - da canaleB a server
    mkfifo(canaleB, 0666);
   
    int fd2 = open("/tmp/canaleB", O_RDONLY  | O_NONBLOCK ); // solo lettura
    if (fd2 == -1) {
        perror("Errore apertura SECONDA pipe");
        return 1;
    }
    

    // PIPE 3 - da server a canaleB
    mkfifo(serverB,0666);
    int fd3 = open("/tmp/serverB", O_RDWR | O_NONBLOCK); // lettura e scrittura
    if (fd3 == -1) {
        printf("Errore apertura TERZA pipe");
        return 1;
    }

    // PIPE 4 - da server a canaleA
    mkfifo(serverA, 0666);
    int fd4 = open(serverA, O_RDWR | O_NONBLOCK); //lettura e scrittura
    if (fd4 == -1) {
        printf("Errore apertura QUARTA pipe");
        return 1;
    }
// FINE CREAZIONE PIPE
while(1){
    printf("il server sta facendo il suo lavoro");
    int  n=read(fd,dom,sizeof(dom)); // controllo se ci sono mess sul canale a 
     scanf(" %255s", dom);
    if((n!=0) && (n!=-1)){ // se ci sono li mando a b
        write(fd3,dom,sizeof(dom));
        
    }else{
        int  g=read(fd2,dom,sizeof(dom)); // se non trovo nulla, controllo se ci sono su b, se ci sono li mando ad a
        if((g!=0) && (g!=-1)){
            write(fd4,dom,sizeof(dom));
    }

        
    }
}
return 0;
}